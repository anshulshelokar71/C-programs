//Yes
// int length= sizeof(arr)/sizeof(element);